
// Helpers robustos
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

// Base de Dados de Produtos com preços reais de mercado vigentes no Brasil
const PRODUCTS = [
  {id:1, cat:'medicamentos', name:'Dipirona Monoidratada 500mg Genérico (10 comp)', price:4.20, desc:'Analgésico e antitérmico para alívio rápido de dores de cabeça e febre.', img:'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80'},
  {id:2, cat:'medicamentos', name:'Paracetamol 750mg Genérico (20 comp)', price:9.80, desc:'Eficaz no alívio de dores moderadas e controle da temperatura corporal.', img:'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=600&q=80'},
  {id:3, cat:'medicamentos', name:'Omeprazol 20mg Genérico (28 cápsulas)', price:13.50, desc:'Protetor gástrico para tratamento de azia, refluxo e queimação estomacal.', img:'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=600&q=80'},
  {id:4, cat:'medicamentos', name:'Loratadina 10mg Antialérgico (12 comp)', price:8.90, desc:'Alívio rápido de crises alérgicas respiratórias e coriza sem causar sono.', img:'https://images.unsplash.com/photo-1550572017-edd951aa8f72?auto=format&fit=crop&w=600&q=80'},
  {id:5, cat:'vitaminas', name:'Vitamina C 1g Efervescente Redoxon / Cewin (10 comp)', price:18.90, desc:'Auxilia no fortalecimento do sistema imune e ação antioxidante diária.', img:'https://images.unsplash.com/photo-1616671285442-1e9a444983df?auto=format&fit=crop&w=600&q=80'},
  {id:6, cat:'vitaminas', name:'Multivitamínico Centrum / Lavitan A-Z (60 cáps)', price:36.90, desc:'Fórmula diária com micronutrientes essenciais para energia e disposição no trabalho.', img:'https://images.unsplash.com/photo-1577401239170-897942555fb3?auto=format&fit=crop&w=600&q=80'},
  {id:7, cat:'vitaminas', name:'Vitamina D3 2.000 UI Addera (30 cáps)', price:27.90, desc:'Manutenção da saúde óssea e reforço da imunidade celular diária.', img:'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=600&q=80'},
  {id:8, cat:'higiene', name:'Álcool em Gel Antisséptico 70% Asseptgel (500ml)', price:9.50, desc:'Higiene instantânea para mãos com hidratante para não ressecar a pele.', img:'https://images.unsplash.com/photo-1584744982491-665216d95f8b?auto=format&fit=crop&w=600&q=80'},
  {id:9, cat:'higiene', name:'Protetor Solar Facial Antioleosidade FPS 60 (50g)', price:49.90, desc:'Toque seco ultraleve, ideal para o sol intenso do Rio de Janeiro.', img:'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80'},
  {id:10, cat:'primeiros-socorros', name:'Curativos Adesivos Band-Aid Tradicional (30 un)', price:11.90, desc:'Proteção respirável e impermeável para pequenos cortes e escoriações.', img:'https://images.unsplash.com/photo-1603398938378-e54eab446dde?auto=format&fit=crop&w=600&q=80'},
  {id:11, cat:'primeiros-socorros', name:'Soro Fisiológico Estéril 0,9% Needs / ADV (500ml)', price:5.80, desc:'Higienização nasal, de ferimentos e lentes de contato.', img:'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=600&q=80'},
  {id:12, cat:'primeiros-socorros', name:'Gaze Estéril 7,5 x 7,5cm Cremer (pacote c/ 10)', price:3.20, desc:'Gaze pura de algodão para curativos e assepsia médica.', img:'https://images.unsplash.com/photo-1628771065518-0d82f1938462?auto=format&fit=crop&w=600&q=80'}
];

// Estado global do carrinho e usuário
let cart = [];
try {
  const savedCart = localStorage.getItem('dw_cart');
  if (savedCart) {
    const parsed = JSON.parse(savedCart);
    if (Array.isArray(parsed)) {
      cart = parsed.map(cItem => {
        const currentProd = PRODUCTS.find(p => p.id === cItem.id);
        return currentProd ? {...cItem, price: currentProd.price, name: currentProd.name} : cItem;
      });
    }
  }
} catch(e){}

// Toast helper
function showToast(msg) {
  const toast = $('#toast');
  const msgEl = $('#toastMsg');
  if (!toast || !msgEl) return;
  msgEl.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3200);
}

// 1. Navegação SPA e Roteamento
try {
  function switchPage(pageId) {
    const pages = $$('[data-page]');
    const links = $$('.nav-link');
    pages.forEach(p => {
      if (p.getAttribute('data-page') === pageId) {
        p.classList.add('active');
      } else {
        p.classList.remove('active');
      }
    });
    links.forEach(l => {
      if (l.getAttribute('data-target') === pageId) {
        l.classList.add('active');
      } else {
        l.classList.remove('active');
      }
    });
    window.scrollTo({top: 0, behavior: 'smooth'});
    window.location.hash = pageId;
    $('#navMenu')?.classList.remove('mobile-open');
  }

  document.addEventListener('click', e => {
    const targetLink = e.target.closest('[data-target]');
    if (targetLink) {
      e.preventDefault();
      const page = targetLink.getAttribute('data-target');
      switchPage(page);
    }
  });

  window.addEventListener('load', () => {
    const hash = window.location.hash.replace('#', '');
    if (hash && $(`[data-page="${hash}"]`)) {
      switchPage(hash);
    }
  });

  $('#burgerBtn')?.addEventListener('click', () => {
    $('#navMenu')?.classList.toggle('mobile-open');
  });
} catch(e){}

// 2. Barra de Progresso e Header ao Rolar
try {
  window.addEventListener('scroll', () => {
    const h = document.documentElement;
    const st = h.scrollTop || document.body.scrollTop;
    const sh = h.scrollHeight - h.clientHeight;
    const pct = (st / (sh || 1)) * 100;
    const bar = $('#scrollBar');
    if (bar) bar.style.width = pct + '%';
  });
} catch(e){}

// 3. Tema Claro / Escuro
try {
  const themeBtn = $('#themeToggle');
  let currentTheme = 'dark';
  try {
    const st = localStorage.getItem('dw_theme');
    if (st) currentTheme = st;
  } catch(e){}
  document.documentElement.setAttribute('data-theme', currentTheme);

  themeBtn?.addEventListener('click', () => {
    currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', currentTheme);
    try { localStorage.setItem('dw_theme', currentTheme); } catch(e){}
    showToast(currentTheme === 'dark' ? 'Modo Escuro ativado' : 'Modo Claro ativado');
  });
} catch(e){}

// 4. Renderização do Catálogo & Filtros & Busca
try {
  const grid = $('#catalogGrid');
  const renderCatalog = (items) => {
    if (!grid) return;
    if (items.length === 0) {
      grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-muted)">Nenhum medicamento encontrado para essa busca.</div>';
      return;
    }
    grid.innerHTML = items.map(p => `
      <div class="product-card fade-up visible">
        <div class="product-img-wrap">
          <img src="${p.img}" alt="${p.name}" loading="lazy">
        </div>
        <div class="product-info">
          <span class="product-category">${p.cat}</span>
          <h4 class="product-title">${p.name}</h4>
          <p class="product-desc">${p.desc}</p>
          <div class="product-foot">
            <span class="product-price">R$ ${p.price.toFixed(2).replace('.', ',')}</span>
            <button class="btn btn-primary btn-sm" data-add="${p.id}">+ Adicionar</button>
          </div>
        </div>
      </div>
    `).join('');
  };

  renderCatalog(PRODUCTS);

  // Filtros de Categoria
  $$('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      $$('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.getAttribute('data-cat');
      const query = $('#searchInput')?.value.toLowerCase().trim() || '';
      applyFilters(cat, query);
    });
  });

  // Busca
  $('#searchInput')?.addEventListener('input', e => {
    const query = e.target.value.toLowerCase().trim();
    const activeCat = $('.cat-btn.active')?.getAttribute('data-cat') || 'todos';
    applyFilters(activeCat, query);
  });

  function applyFilters(cat, query) {
    let filtered = PRODUCTS;
    if (cat !== 'todos') {
      filtered = filtered.filter(p => p.cat === cat);
    }
    if (query) {
      filtered = filtered.filter(p => p.name.toLowerCase().includes(query) || p.desc.toLowerCase().includes(query));
    }
    renderCatalog(filtered);
  }
} catch(e){}

// 5. Carrinho Funcional com Integração WhatsApp
try {
  const drawer = $('#cartDrawer');
  const overlay = $('#overlay');
  const cartToggle = $('#cartToggle');
  const closeCart = $('#closeCart');
  const badge = $('#cartBadge');
  const itemsContainer = $('#cartItemsContainer');
  const totalValEl = $('#cartTotalVal');

  function updateCartUI() {
    try { localStorage.setItem('dw_cart', JSON.stringify(cart)); } catch(e){}
    const totalCount = cart.reduce((acc, item) => acc + item.qty, 0);
    if (badge) badge.textContent = totalCount;

    if (!itemsContainer) return;
    if (cart.length === 0) {
      itemsContainer.innerHTML = '<div style="text-align:center;padding:40px 10px;color:var(--text-muted)">Seu carrinho está vazio. Adicione medicamentos ou itens de cuidados.</div>';
      if (totalValEl) totalValEl.textContent = 'R$ 0,00';
      return;
    }

    let total = 0;
    itemsContainer.innerHTML = cart.map(item => {
      const sub = item.price * item.qty;
      total += sub;
      return `
        <div class="cart-item">
          <img src="${item.img}" alt="${item.name}">
          <div style="flex:1">
            <h5 style="font-size:.9rem;font-weight:700">${item.name}</h5>
            <div style="font-size:.8rem;color:var(--text-muted)">R$ ${item.price.toFixed(2).replace('.', ',')}</div>
            <div style="font-weight:700;font-size:.88rem;margin-top:4px">R$ ${sub.toFixed(2).replace('.', ',')}</div>
          </div>
          <div class="cart-ctrl">
            <button data-dec="${item.id}">-</button>
            <span style="font-weight:600;font-size:.9rem">${item.qty}</span>
            <button data-inc="${item.id}">+</button>
          </div>
          <button style="background:none;border:none;color:#ef4444;cursor:pointer;padding:4px" data-del="${item.id}">✕</button>
        </div>
      `;
    }).join('');

    if (totalValEl) totalValEl.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
  }

  function openDrawer() {
    drawer?.classList.add('open');
    overlay?.classList.add('open');
  }

  function closeDrawer() {
    drawer?.classList.remove('open');
    overlay?.classList.remove('open');
  }

  cartToggle?.addEventListener('click', openDrawer);
  closeCart?.addEventListener('click', closeDrawer);
  overlay?.addEventListener('click', () => {
    closeDrawer();
    $('#lightbox')?.classList.remove('open');
  });

  // Delegação de eventos no Documento para adicionar / alterar carrinho
  document.addEventListener('click', e => {
    const addBtn = e.target.closest('[data-add]');
    if (addBtn) {
      const pId = parseInt(addBtn.getAttribute('data-add'), 10);
      const prod = PRODUCTS.find(p => p.id === pId);
      if (prod) {
        const exist = cart.find(c => c.id === pId);
        if (exist) {
          exist.qty++;
        } else {
          cart.push({...prod, qty: 1});
        }
        updateCartUI();
        showToast(`"${prod.name}" adicionado ao carrinho!`);
      }
    }

    const incBtn = e.target.closest('[data-inc]');
    if (incBtn) {
      const id = parseInt(incBtn.getAttribute('data-inc'), 10);
      const item = cart.find(c => c.id === id);
      if (item) { item.qty++; updateCartUI(); }
    }

    const decBtn = e.target.closest('[data-dec]');
    if (decBtn) {
      const id = parseInt(decBtn.getAttribute('data-dec'), 10);
      const item = cart.find(c => c.id === id);
      if (item) {
        item.qty--;
        if (item.qty <= 0) cart = cart.filter(c => c.id !== id);
        updateCartUI();
      }
    }

    const delBtn = e.target.closest('[data-del]');
    if (delBtn) {
      const id = parseInt(delBtn.getAttribute('data-del'), 10);
      cart = cart.filter(c => c.id !== id);
      updateCartUI();
      showToast('Item removido do carrinho.');
    }
  });

  // Finalizar no WhatsApp (DADOS REAIS: 21 2233-8989)
  $('#btnCheckout')?.addEventListener('click', () => {
    if (cart.length === 0) {
      alert('Seu carrinho está vazio! Adicione algum produto antes de finalizar.');
      return;
    }
    const name = $('#cartClientName')?.value.trim() || 'Cliente';
    const address = $('#cartClientAddress')?.value.trim() || 'Retirada na Loja (Av. Pres. Vargas, 542)';
    const payment = $('#cartPayment')?.value || 'A combinar';

    let total = 0;
    let listText = '';
    cart.forEach(item => {
      const sub = item.price * item.qty;
      total += sub;
      listText += `• ${item.qty}x ${item.name} - R$ ${sub.toFixed(2).replace('.', ',')}\n`;
    });

    const msg = `*NOVO PEDIDO - DROGARIA WILSON CENTRO*\n` +
      `----------------------------------------\n` +
      `*Cliente:* ${name}\n` +
      `*Endereço:* ${address}\n` +
      `*Pagamento:* ${payment}\n\n` +
      `*Itens do Pedido:*\n${listText}\n` +
      `*TOTAL:* R$ ${total.toFixed(2).replace('.', ',')}\n` +
      `----------------------------------------\n` +
      `Por favor, confirme a disponibilidade e o prazo de entrega.`;

    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/552122338989?text=${encoded}`, '_blank');
  });

  updateCartUI();
} catch(e){}

// 6. Formulário de Contato Direto via WhatsApp
try {
  $('#contactForm')?.addEventListener('submit', e => {
    e.preventDefault();
    const nome = $('#cNome')?.value.trim();
    const tel = $('#cTel')?.value.trim();
    const assunto = $('#cAssunto')?.value;
    const msg = $('#cMsg')?.value.trim();

    const text = `*MENSAGEM VIA SITE - DROGARIA WILSON*\n` +
      `*Nome:* ${nome}\n` +
      `*Telefone:* ${tel}\n` +
      `*Assunto:* ${assunto}\n` +
      `*Mensagem:* ${msg}`;

    window.open(`https://wa.me/552122338989?text=${encodeURIComponent(text)}`, '_blank');
    showToast('Redirecionando para o WhatsApp da Drogaria Wilson...');
  });

  // Botões de Serviços Farmacêuticos
  document.addEventListener('click', e => {
    const sBtn = e.target.closest('[data-service]');
    if (sBtn) {
      const serv = sBtn.getAttribute('data-service');
      const text = `Olá! Gostaria de informações ou agendamento para o serviço farmacêutico: *${serv}* na Drogaria Wilson Centro.`;
      window.open(`https://wa.me/552122338989?text=${encodeURIComponent(text)}`, '_blank');
    }
  });
} catch(e){}

// 7. Acordeão de Dúvidas
try {
  $$('.accordion-head').forEach(head => {
    head.addEventListener('click', () => {
      const parent = head.parentElement;
      const isOpen = parent.classList.contains('open');
      $$('.accordion-item').forEach(i => i.classList.remove('open'));
      if (!isOpen) parent.classList.add('open');
    });
  });
} catch(e){}

// 8. Carrossel Automático e Manual
try {
  const slides = $('#carouselSlides');
  const dots = $$('#carouselDots .dot');
  let currentSlide = 0;
  const totalSlides = 3;

  function goToSlide(n) {
    currentSlide = (n + totalSlides) % totalSlides;
    if (slides) slides.style.transform = `translateX(-${currentSlide * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === currentSlide));
  }

  $('#carNext')?.addEventListener('click', () => goToSlide(currentSlide + 1));
  $('#carPrev')?.addEventListener('click', () => goToSlide(currentSlide - 1));
  dots.forEach((dot, idx) => {
    dot.addEventListener('click', () => goToSlide(idx));
  });

  setInterval(() => {
    goToSlide(currentSlide + 1);
  }, 6500);
} catch(e){}

// 9. Galeria Lightbox Simples
try {
  const lb = $('#lightbox');
  const lbImg = $('#lightboxImg');
  $$('.gallery-thumb').forEach(thumb => {
    thumb.addEventListener('click', () => {
      const src = thumb.getAttribute('data-img');
      if (lb && lbImg && src) {
        lbImg.src = src;
        lb.classList.add('open');
      }
    });
  });

  lb?.addEventListener('click', () => {
    lb.classList.remove('open');
  });
} catch(e){}

// 10. Contadores Animados via IntersectionObserver
try {
  const counters = $$('.stat-num');
  const obs = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseFloat(el.getAttribute('data-count'));
        let start = 0;
        const duration = 1600;
        const isDecimal = target % 1 !== 0;
        const stepTime = 20;
        const steps = duration / stepTime;
        const inc = target / steps;

        const timer = setInterval(() => {
          start += inc;
          if (start >= target) {
            el.textContent = isDecimal ? target.toFixed(1) : Math.floor(target);
            clearInterval(timer);
          } else {
            el.textContent = isDecimal ? start.toFixed(1) : Math.floor(start);
          }
        }, stepTime);

        observer.unobserve(el);
      }
    });
  }, {threshold: 0.4});

  counters.forEach(c => obs.observe(c));
} catch(e){}

// 11. Animações Reveal ao rolar (Fade Up)
try {
  const reveals = $$('.fade-up');
  const revObs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, {threshold: 0.15});
  reveals.forEach(r => revObs.observe(r));
} catch(e){}

// 12. Modal Perfil & Gamificação (localStorage)
try {
  const profModal = $('#profileModal');
  const profileBtn = $('#profileBtn');
  const closeProfile = $('#closeProfile');
  const nameInput = $('#inputSaveName');
  const nameDisplay = $('#userNameDisplay');

  try {
    const savedName = localStorage.getItem('dw_username');
    if (savedName && nameDisplay) {
      nameDisplay.textContent = savedName;
      if (nameInput) nameInput.value = savedName;
    }
  } catch(e){}

  profileBtn?.addEventListener('click', () => profModal?.classList.add('open'));
  closeProfile?.addEventListener('click', () => profModal?.classList.remove('open'));

  $('#saveProfileBtn')?.addEventListener('click', () => {
    const val = nameInput?.value.trim();
    if (val) {
      try { localStorage.setItem('dw_username', val); } catch(e){}
      if (nameDisplay) nameDisplay.textContent = val;
      showToast('Perfil atualizado com sucesso!');
      profModal?.classList.remove('open');
    }
  });
} catch(e){}

// 13. Onboarding de Primeira Visita
try {
  const onboard = $('#onboardModal');
  let hasVisited = false;
  try {
    hasVisited = localStorage.getItem('dw_visited');
  } catch(e){}

  if (!hasVisited && onboard) {
    setTimeout(() => {
      onboard.classList.add('open');
    }, 1200);
  }

  $('#closeOnboard')?.addEventListener('click', () => {
    onboard?.classList.remove('open');
    try { localStorage.setItem('dw_visited', 'true'); } catch(e){}
  });
} catch(e){}
